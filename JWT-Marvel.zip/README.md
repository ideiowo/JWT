# MCDX-JWT
- Buy without paying any credit
- Get the permission to use control panel
# Environment
- [NodeJS](https://nodejs.org/en/)
# Setup
- ``cd path_to_folder``
- ``sudo apt-get update``
- ``sudo apt-get install -y nodejs``
- ``sudo apt-get install npm``
- After getting node env, go into the directory and simply type ``npm start`` to open the server on port 9999

