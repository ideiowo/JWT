var userInfo = {
    user1: {
        uid: 1,
        user: 'user1',
        password: 'user1password',
        email: 'user1@example.com',
        credit: 1000,
        privilege: 0
    },
    user2: {
        uid: 2,
        user: 'user2',
        password: 'user2password',
        email: 'user2@example.com',
        credit: 10000,
        privilege: 0
    },
}

module.exports = {
    info: userInfo
}