var goods = {
    '無限手套': {
        id: 1,
        price: 9999999
    },
    '雷神之錘': {
        id: 2,
        price: 5555555
    },
    '方舟反應爐': {
        id: 3,
        price: 1111111
    },
}

module.exports = goods