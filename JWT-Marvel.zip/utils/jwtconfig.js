var settings = {
    jwt_key: 'secret_key',
    jwt_expire_in: 600 * 1000 // 10 min
}

module.exports = {
    settings: settings
}